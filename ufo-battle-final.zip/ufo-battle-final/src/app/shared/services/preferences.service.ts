import { Inject, Injectable, PLATFORM_ID } from "@angular/core";
import { isPlatformBrowser } from "@angular/common";

@Injectable({
  providedIn: "root",
})
export class PreferencesService {
  private defaultUfoCount: number = 1;
  private defaultTime: number = 60;

  constructor(@Inject(PLATFORM_ID) private platformId: any) {}

  getUfoCount(): number {
    if (!isPlatformBrowser(this.platformId)) {
      return this.defaultUfoCount;
    }
    const ufoCountStr = localStorage.getItem("ufoCount");
    const ufoCount = ufoCountStr ? parseInt(ufoCountStr, 10) : null;
    return ufoCount !== null && !isNaN(ufoCount)
      ? ufoCount
      : this.defaultUfoCount;
  }

  getTime(): number {
    if (!isPlatformBrowser(this.platformId)) {
      return this.defaultTime;
    }
    const timeStr = localStorage.getItem("time");
    const time = timeStr ? parseInt(timeStr, 10) : null;
    return time !== null && !isNaN(time) ? time : this.defaultTime;
  }

  setUfoCount(ufoCount: number): void {
    if (isPlatformBrowser(this.platformId))
      localStorage.setItem("ufoCount", ufoCount.toString());
  }

  setTime(time: number): void {
    if (isPlatformBrowser(this.platformId))
      localStorage.setItem("time", time.toString());
  }
}
