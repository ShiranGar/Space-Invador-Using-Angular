
export let config={
    base_url:"http://wd.etsisi.upm.es:10000"
}