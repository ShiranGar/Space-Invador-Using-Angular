import { TokenmngService } from './../shared/services/tokenmng.service';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/services/user-service.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit{
  password: string = '';
  repeatPassword: string = '';
  loggedInUser: string = '';

  constructor(private userService: UserService, private toknenMng:TokenmngService) { }

  ngOnInit(): void {
    // Get the logged-in user's name from the TokenManager service
    this.loggedInUser = this.toknenMng.getLoggedInUser();
  }

  submitForm() {
      const username = this.toknenMng.getLoggedInUser();
      this.userService.changePassword(username, this.password)
        .subscribe(
          response => {
            // Handle the response as needed
            alert('Password changed successfully');
            //go to home page
            window.location.href = '/home';
            console.log('Password changed successfully', response);
          },
          error => {
            // Log the error message to the console
            alert('Error changing password, please try again');
            console.error('Error changing password:', error);
          }
        );
  }
  

}
