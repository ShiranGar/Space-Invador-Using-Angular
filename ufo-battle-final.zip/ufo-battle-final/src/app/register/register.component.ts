import { Component, ElementRef, Renderer2, ViewChild} from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { UserService } from "../shared/services/user-service.service";
import { User } from "../shared/models/user";
import { Router } from "@angular/router";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrl: "./register.component.css",
})
export class RegisterComponent {
  user: User = new User();
  repeatPassword: string = "";
  isLoggedIn: boolean = false;
  usernameExists: boolean = false;
  emailFormatIncorrect: boolean = false;
  passwordsNotMatching: boolean = false;
  alertShown: boolean = false;
  @ViewChild("usernameInput") usernameInput!: ElementRef; // Reference to the username input

  constructor(private userService: UserService, private router: Router, private renderer:Renderer2) {}

  checkUsername() {
    if (this.user.username) {
      this.userService.checkUsernameExists(this.user.username).subscribe({
        next: (exists: boolean) => {
          if (exists && !this.alertShown) {
            alert("User is already registered.");
            this.alertShown = true; // Set the flag to true after showing the alert
            this.usernameExists = true;
            this.setFocusOnUsername();
          } else {
            // Reset the flag if the username exists but user has modified it
            this.alertShown = false;
            this.usernameExists = exists;
          }
        },
      });
    }
  }

  setFocusOnUsername() {
    this.renderer.selectRootElement(this.usernameInput.nativeElement).focus();
  }

    // Function to validate email format
    isValidEmailFormat(email: string): boolean {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    }

  onSubmit() {
    if (!this.isValidEmailFormat(this.user.email)) {
      this.emailFormatIncorrect = true;
      alert("Email format is incorrect.");
      return;
    } else {
      this.emailFormatIncorrect = false;
    }

    //cheeck the length of the username
    if (this.user.username.length > 8) {
      alert("Username's length must be less or equal to 8 characters.");
      return;
    }
    // Check if passwords match
    // if (this.user.password !== this.repeatPassword) {
    //   this.passwordsNotMatching = true;
    //   alert("Passwords do not match.");
    //   return;
    // } else {
    //     this.passwordsNotMatching = false;
    // }

    this.userService.registerUser(this.user).subscribe({
      next: () => {
        alert("User registered successfully.");
        this.router.navigate(["/login"]);
      },
      error: (error) => {
        if (error.status === 409) alert("User is already registered.");
        else alert("There was an error registering the user.");
      },
    });
  }
}
